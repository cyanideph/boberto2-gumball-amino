from BotAmino import *
from random import *
from time import *
from gtts import gTTS, lang
import os

print("Iniciando...")

client = BotAmino()
client.wait = 2
client.no_command_message = "Comando inválido"
client.spam_message = ""


# A estética base para as coisas do bot
def esteticabase(titulo, conteudo, subtitulo=""):
    return f"""
[c]┏                    ───                      ┓ 
[C]──   Roberto   ──
[C]✩✼　｡ﾟ･　　ﾟ･　☆　° ｡ 
[C] ❤️’• {titulo}
[C]         ╺╺╺╺╺╺╺╺(☕)
[C] — {subtitulo}
{conteudo}
[C]┗                                                  ┛    
        """


# Comando simples que manda msg
@client.command("hello")
def ola(data):
    data.subClient.send_message(data.chatId, "Hello world!")


# !help
@client.command("help")
def ajuda(data):
    # Ele verifica a página pedida e então mostra os comandos
    if data.message == "1":
        data.subClient.send_message(data.chatId, esteticabase("help", """
[c]!ship [Pessoa1, Pessoa2] - Shippa duas pessoas
[c]!pvp [1, 2, rounds] - Pvp entre 2 enttidades com um numero certo de rounds
[c]!spam [Quantidade, mensagem] - Spamma uma mensagem X vezes
[c]!msg [Mensagem] - Manda uma mensagem especificada
[c]!diga [texto] - Manda um áudio dizendo um texto
        """, "Página 1"))


# Comando !ship
@client.command("ship")
def ship(data):
    # Essa parte define as pessoas dadas como argumento (na variavel "pessoas")
    # usando como base o caractére de espaço e, logo após isso verifica a quanti-
    # dade de caracteres em cada nome (no loop for) para que o nome do shipp seja feito sem bugs
    # (ou pelo menos era para não ter bugs)
    # No final, o output é assim: [[pessoa1, False], [pessoa2, True]]
    # Cada item representa a pessoa do argumento mais se o tamanho é menor que 3
    pessoas = (data.message).split(" ")
    pessoas_preserve = (data.message).split(" ")
    for l in range(0, 2):
        if len(pessoas[l]) < 3:
            pessoas[l] = [pessoas[l], True]
        else:
            pessoas[l] = [pessoas[l], False]
    
    shippname = []
    indxlist = []
    # Essa parte é o que define o nome do shipp.
    for index in range(0, 2):
        # Condicional usada para criar o nome do shipp
        if pessoas[index][1]:
            shippname.append(pessoas[index][0])
       # Se essa condição for negativa, será recortado os 3 caracteres iniciais ou os 3 finais
        else:
            if index == 0:
                shippname.append(pessoas[index][0][0:3])
            else:
                reverse = len(pessoas[index][0]) - 4
                for l in range(0, len(pessoas[index][0])+1):
                    reverse += 1
                    shippname.append(pessoas[index][0][reverse])
                    if l == 2:
                        break
    
    # Pega a lista de caracteres gerados e junta em uma string com o nome do ship
    # e então joga tudo para letras minusculas e por fim capitalizando a primeira letra
    shippname = ((''.join(shippname)).lower()).capitalize()

    # Frases, peguei do antigo
    mtruim = ["Mt meloso, eca", "Eles são irmãos, e isso é nojento...", "Eles se odeiam...", "Meh.",
              "Queria muito que isso desse certo, mas nunca vai dar certo.",
              "Eles são apenas amigos...", "Vou ter que te cancelar por shippar isso."]
    ruim = [f"Poderia dar certo se {pessoas[randint(0, 1)][0]} quisesse...", "Okay...", "Eh..."]
    ok = ["Eles ficariam tão bem juntos... Mas fazer o que?", "Confesso que a porcentagem só ta maior que 25 pq eles "
                                                              "são "
                                                              "muito amigos",
          f"{pessoas[0][0]} quer muito ficar com {pessoas[1][0]}, mas {pessoas[1][0]} não quer.", "Não acho que daria "
                                                                                         "certo, mas sempre tem um "
                                                                                         "talvez.",
          "Quem sabe um dia?", "Fofinho, mas nah", f"Eles já estão namorando, mas "
                                                   f"{pessoas[randint(0, 1)][0]} não sabe."]
    bom = ["Eles já estão juntos secretamente.", f"Cara, confesso que só não foi 100% pq {pessoas[randint(0, 1)][0]} é "
                                                 f"kpopper", f"Meu casal <3", "Lindo. Apenas.",
           "Queria ter uma webnamorada :(", ""]
    mtbom = [f"ELES JÁ NAMORAM A {randint(2, 15)} ANOS, COMO VOCÊ NÃO PERCEBEU AINDA??", "Casal muito foda.",
             "É̷͙̪̝̏̿̽̀s̸̳̭̄̅s̸̞̪̊̓̇̂̔e̴̲̰̎͌̌̐͛̍̈́ ̴̡̡̝̙̥̪͕͉͉̈́̎c̸̛̻̼̟̹̭͛̈́͝ͅḁ̶̆̄̿͊̽̕s̶̡̾̑̐a̴̼̱̲̦͍̜̩̖͐̓́̑̆͋̈̅̕l"
             "̷̧̗̬͕͖̯̖͓̻̈́̃̈̒͌̒̚͠ͅ ̴̘̩͖̓͒ͅé̵͔͛͌͐̈́̔̑͛̓̈ ̷͈̹̻̂̈̀̂͋̀͛̃͝t̸̡̛̝̫̯̲̗̻̬͇̎ã̵͖̰̑͆̄̋͒̈̇ő̵͚͓͂̅̈͂̆̃̏̄ "
             "̵̧̮̟͈̟̌͊̑̃͘b̶͉̯͋̕ö̸̧̰͕̥̹͓͙̰͑͐̈́̆̌̄̓͂͝m̴̡̧̰̥̥͖̻̑͌̌͑͐̋ "
             "̵̛͚͕̠̭̳͉͓̘́͜q̴̱̲͓̆͆͗̇̎̅͌̓̈́u̸̧̢̼̞̱͆͑͂̃͋͘͜͠e̴̬̩̬͓̪͍̭͕̓̚͠ ̴̺̍̋͋̆̽͜ṁ̷̱͐́͐͌̈ě̷̛̪̜͔̉͑̀̇̉̑ͅ "
             "̶͍̘̒̾͌̕̕d̸̞̳̱̗͉͙̫̠͖̂͊̋̏̍̆̽̋͜ȃ̴̜̜̮̱̫̺̺̑ "
             "̵̡̨̑̍̓̊̄̅̐̿̊̋ņ̵̬̙̳͕͖̩̫͓̦̍͑͛̅͒̌̇͠o̴̘̯̩͒͆͜j̵͚̖̹̱̠̘̣̟͊̾͂͌͘͝o̸̠͍̳͙̐.̴͑͒́̓̆̕̚͜",
             "Eu fiquei até sem idéia doq escrever de tão bom.", "Aquele casal perfeito...", "bot.exe parou de "
                                                                                             "funcionar."]

    # É definido a porcentagem para que possa ser pego uma frase aleatoria das listas acima
    # Também é definido a variavel do valor restante de porcentagem
    # Esses valores também servirão para criar a barra
    porcentagem = float(f"{uniform(0, 100):.2f}")
    vazio = 100 - porcentagem

    # Por fim, uma condicional para pegar uma string de uma das listas
    if porcentagem <= 10:
        quote = choice(mtruim)
    elif 10 <= porcentagem <= 25:
        quote = choice(ruim)
    elif 25 <= porcentagem <= 50:
        quote = choice(ok)
    elif 50 <= porcentagem <= 75:
        quote = choice(bom)
    elif 75 <= porcentagem <= 100:
        quote = choice(mtbom)

    # Enviar a mensagem final
    data.subClient.send_message(data.chatId, esteticabase(shippname, f"""   
[c]
[c][{"█" * int(porcentagem / 5)}{"⠀" * int(vazio / 5)}]
[ciu]{porcentagem}% de dar certo.
[ci]
[ci]"{quote}"
""", f"{pessoas_preserve[0]} x {pessoas_preserve[1]}"))


# !pvp
@client.command("pvp")
def fight(data):
    # Argumentos
    args = (data.message).split(" ")
    args.append(5)

    # Aqui acontece o jogo em si
    score = [0, 0]
    r = 0
    for l in range(0, int(args[2])):
        r +=1
        score[0] = score[0] + randint(0, 1)
        score[1] = score[1] + randint(0, 1)

        # É definido o vencedor desse round
        if score[0] > score[1]:
            winner = args[0]
        elif score[0] < score[1]:
            winner = args[1]
        else:
            winner = "Ninguém"
        data.subClient.send_message(data.chatId, esteticabase("PvP", f"""
[cu]{args[0]} {score[0]} x {score[1]} {args[1]}
[c]
[c]{winner} está em vantagem!
        """, f"Round {r}"))
        sleep(1)
    data.subClient.send_message(data.chatId, f"{winner} venceu.")


# !spam
@client.command("spam")
def flood(data):
    args = (data.message).split(" ")
    for l in range(0, int(args[0])):
        data.subClient.send_message(data.chatId, ' '.join(args[1:]))
        sleep(1)


# !msg
@client.command("msg")
def sms(data):
    data.subClient.send_message(data.chatId, data.message)


# !cancelar
@client.command("cancelar")
def cancel(data):
    # A pessoa cancelada em questão
    pessoa = data.message

    # Os motivos de cancelamentos estão aqui:
    data.subClient.send_message(data.chatId, esteticabase(f"Cancelado", subtitulo=f"{pessoa} foi enviado(a) para a prisão após sofrer cancelamento.",
    conteudo=f"""
[c]
[c]O motivo é que {pessoa} {choice(['shippou incesto', 'disse que não gosta de gatos', 'a',
'gosta do Felipe Neto', "não gosta de Gumball", "é o Neymar", "é gado para caralho", "é lindo dms", "gosta de Kpop", 
"não fez nada", "é comunista", "apoia o anarcocapitalismo", "apoia o narcotráfico", "被中共黑了"])}."""))


# !diga
@client.command("diga")
def say_something(data):
    audio_file = f"audios/ttp.mp3"
    gTTS(text=data.message, lang='pt', slow=False).save(audio_file)
    with open(audio_file, 'rb') as fp:
        data.subClient.send_message(data.chatId, file=fp, fileType="audio")
        os.remove(audio_file)


# !audio
@client.command("audio")
def audio(data):
    audio_file = f"audios/audio/{data.message}.mp3"
    with open(audio_file, 'rb') as fp:
        data.subClient.send_message(data.chatId, file=fp, fileType="audio")


client.launch()
print("pronto")
